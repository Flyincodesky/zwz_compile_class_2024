main(){
	int a,b,c;
    a=1;
    while(a<1000){
    a=a+1;
    b=a*2;
    c=5;
    }
    b=add(b,c);
    print(b);
}
add(x, y){
    return x+y;
}